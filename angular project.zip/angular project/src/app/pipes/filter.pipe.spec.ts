import { TrophyFilterPipe } from './filter.pipe';

describe('FilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TrophyFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
