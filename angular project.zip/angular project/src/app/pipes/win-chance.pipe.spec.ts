import { WinChancePipe } from './win-chance.pipe';

describe('WinChancePipe', () => {
  it('create an instance', () => {
    const pipe = new WinChancePipe();
    expect(pipe).toBeTruthy();
  });
});
