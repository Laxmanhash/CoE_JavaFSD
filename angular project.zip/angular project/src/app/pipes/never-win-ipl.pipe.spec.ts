import { NeverWinIplPipe } from './never-win-ipl.pipe';

describe('NeverWinIplPipe', () => {
  it('create an instance', () => {
    const pipe = new NeverWinIplPipe();
    expect(pipe).toBeTruthy();
  });
});
