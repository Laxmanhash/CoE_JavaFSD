package com.example.task1proj

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
